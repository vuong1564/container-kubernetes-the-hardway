#!/bin/sh

echo "Practical DevOps in ARM64"
