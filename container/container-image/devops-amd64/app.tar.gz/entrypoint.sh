#!/bin/sh
echo "Practical DevOps in amd64"
